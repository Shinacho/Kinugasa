﻿#include "twoone_game_input_GamePadConnection.h"
#include "lib\jni.h"
#include <d2d1.h>
#include <Xinput.h>

#pragma comment(lib,"Xinput.lib")


static XINPUT_STATE state;
static XINPUT_GAMEPAD gamepad;


JNIEXPORT jfloatArray JNICALL Java_twoone_game_input_GamePadConnection_getNativeState(JNIEnv* env, jclass thisj, jint plIdx) {
 jfloatArray result = env->NewFloatArray(twoone_game_input_GamePadConnection_LENGTH);
 ZeroMemory(&state, sizeof(XINPUT_STATE));
 DWORD connection = XInputGetState(plIdx, &state);
 gamepad = state.Gamepad;
 float stateData[twoone_game_input_GamePadConnection_LENGTH];
 stateData[twoone_game_input_GamePadConnection_BUTTON_A] = float(gamepad.wButtons & XINPUT_GAMEPAD_A);
 stateData[twoone_game_input_GamePadConnection_BUTTON_B] = float(gamepad.wButtons & XINPUT_GAMEPAD_B);
 stateData[twoone_game_input_GamePadConnection_BUTTON_X] = float(gamepad.wButtons & XINPUT_GAMEPAD_X);
 stateData[twoone_game_input_GamePadConnection_BUTTON_Y] = float(gamepad.wButtons & XINPUT_GAMEPAD_Y);
 stateData[twoone_game_input_GamePadConnection_BUTTON_LB] = float(gamepad.wButtons & XINPUT_GAMEPAD_LEFT_SHOULDER);
 stateData[twoone_game_input_GamePadConnection_BUTTON_RB] = float(gamepad.wButtons & XINPUT_GAMEPAD_RIGHT_SHOULDER);
 stateData[twoone_game_input_GamePadConnection_BUTTON_LEFT_STICK] = float(gamepad.wButtons & XINPUT_GAMEPAD_LEFT_THUMB);
 stateData[twoone_game_input_GamePadConnection_BUTTON_RIGHT_STICK] = float(gamepad.wButtons & XINPUT_GAMEPAD_RIGHT_THUMB);
 stateData[twoone_game_input_GamePadConnection_BUTTON_POV_UP] = float(gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP);
 stateData[twoone_game_input_GamePadConnection_BUTTON_POV_DOWN] = float(gamepad.wButtons & XINPUT_GAMEPAD_DPAD_DOWN);
 stateData[twoone_game_input_GamePadConnection_BUTTON_POV_LEFT] = float(gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT);
 stateData[twoone_game_input_GamePadConnection_BUTTON_POV_RIGHT] = float(gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT);
 stateData[twoone_game_input_GamePadConnection_BUTTON_START] = float(gamepad.wButtons & XINPUT_GAMEPAD_START);
 stateData[twoone_game_input_GamePadConnection_BUTTON_BACK] = float(gamepad.wButtons & XINPUT_GAMEPAD_BACK);
 stateData[twoone_game_input_GamePadConnection_TRIGGER_LEFT] = (float)gamepad.bLeftTrigger / (float)twoone_game_input_GamePadConnection_TRIGGER_MAX;
 stateData[twoone_game_input_GamePadConnection_TRIGGER_RIGHT] = (float)gamepad.bRightTrigger / (float)twoone_game_input_GamePadConnection_TRIGGER_MAX;
 stateData[twoone_game_input_GamePadConnection_THUMB_STICK_LEFT_X] = (float)gamepad.sThumbLX / (float)twoone_game_input_GamePadConnection_THUMSTICK_ABS_MAX * 2.0f;
 stateData[twoone_game_input_GamePadConnection_THUMB_STICK_LEFT_Y] = (float)gamepad.sThumbLY / (float)twoone_game_input_GamePadConnection_THUMSTICK_ABS_MAX * 2.0f;
 stateData[twoone_game_input_GamePadConnection_THUMB_STICK_RIGHT_X] = (float)gamepad.sThumbRX / (float)twoone_game_input_GamePadConnection_THUMSTICK_ABS_MAX * 2.0f;
 stateData[twoone_game_input_GamePadConnection_THUMB_STICK_RIGHT_Y] = (float)gamepad.sThumbRY / (float)twoone_game_input_GamePadConnection_THUMSTICK_ABS_MAX * 2.0f;
 stateData[twoone_game_input_GamePadConnection_CONNECTION] = (connection == ERROR_SUCCESS);
 jfloat* aryP = env->GetFloatArrayElements(result, NULL);
 for (int i = 0; i < twoone_game_input_GamePadConnection_LENGTH; i++) aryP[i] = stateData[i];
 env->ReleaseFloatArrayElements(result, aryP, 0);
 return result;
}

JNIEXPORT void JNICALL Java_twoone_game_input_GamePadConnection_free(JNIEnv* env, jclass thisj) {
 free(&state);
 free(&gamepad);
}
