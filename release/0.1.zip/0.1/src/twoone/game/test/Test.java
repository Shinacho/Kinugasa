/*
 * The MIT License
 *
 * Copyright 2021 Dra.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

package twoone.game.test;

import twoone.game.GameManager;
import twoone.game.GameOption;
import twoone.game.GameTimeManager;
import twoone.game.GraphicsContext;
import twoone.game.LockUtil;
import twoone.game.input.InputState;
import twoone.game.input.InputType;
import twoone.game.input.Keys;
import twoone.resource.sound.SoundBuilder;

/**
 *
 * @vesion 1.0.0 - 2021/08/17_14:12:16<br>
 * @author Dra211<br>
 */
public class Test extends GameManager{

	
	public static void main(String[] args) {
		LockUtil.deleteAllLockFile();
		new Test().gameStart(args);
	}
	
	private Test(){
		super(GameOption.defaultOption().setCenterOfScreen());
	}

	@Override
	protected void startUp() {
		// �Q�[���J�n����1�񂾂����s
		new SoundBuilder("C:/users/owner/desktop/test.wav").builde().load().play();
	}

	@Override
	protected void dispose() {
		// �Q�[���I������1�񂾂����s
	}

	@Override
	protected void update(GameTimeManager gtm) {
		// �ݒ肵��FPS�Ŏ��s
		if(InputState.getInstance().isPressed(Keys.ESCAPE, InputType.SINGLE)){
			gameExit();
		}
		if(InputState.getInstance().getGamePadState().buttons.BACK){
			gameExit();
		}
	}

	@Override
	protected void draw(GraphicsContext gc) {
		// �ݒ肵��FPS�Ŏ��s
	}
	
	
}
